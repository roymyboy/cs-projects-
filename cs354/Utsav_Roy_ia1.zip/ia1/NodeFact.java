/**
 * Abstract class extends Node class
 */
public abstract class NodeFact extends Node {}

